from flask import Flask, session, request, redirect, render_template #Here we initiate flask, call session data, and actions
import random #Allow random function
 
app = Flask(__name__) #create our app within whcich everything is stored

app.secret_key = 's3cr3tk3y' # set the secret key necessary for all sessions

@app.route('/') #set our initial render
def indexIG():   #the initial render function
	if not 'gold' in session: #we set the session info gold at 0 if it isn't already created 
		session['gold'] = 0
	if not 'log' in session: # our two session info pieces are gold and log, one an integer, the other a string 
		session['log'] = ''
	data = {} #set data to an empty dictionary
	data['gold'] = session['gold']
	data['log'] = session['log']
	return render_template('indexIG.html', data=data)

@app.route('/process_money', methods=['POST'])
def process():
	loc = request.form['location']
	print loc
	if loc == 'Farm':
		rand = random.randrange(10, 21)
		message = "<div class='won'>You went to the farm and earned " + str(rand) + " gold!</div>"
	elif loc == 'Cave':
		rand = random.randrange(5, 11)
		message = "<div class='won'>You went to the cave and earned " + str(rand) + " gold!</div>"
	elif loc == 'House':
		rand = random.randrange(2, 6)
		message = "<div class='won'>You went to the house and earned " + str(rand) + " gold!</div>"
	elif loc == 'Casino':
		rand = random.randrange(-50, 51)
		if rand < 0:
			win_or_loss = 'lost'
		else:
			win_or_loss = 'won'
		message = "<div class='" + win_or_loss + "'>You went to the casino and " + win_or_loss + " " + str(rand) + " gold!</div>"
 


	log = session['log'] #here we capture capture the existing session[log] data in the log variable
	session['log'] = message + log #we reassign the session log memory to our message string + 
	session['gold'] += rand
	print session['log']
	return redirect('/')

@app.route('/reset', methods=['POST'])
def reset():
	session['gold'] = 0
	session['log'] = ''
	return redirect('/')

app.run(debug=True)

#initialize data at key gold equal to the session['gold'] info, and session['log'] stored info
    #request info from form name 'location' will pass into the route method, through the process function, where it 
	#will be captured by the 'loc' variable and pass into the if function where it's 
    # value will be checked to ID which form it came from. With that variable method 
	#will be assigned a string with: "div won assigned to a message" + the rand generated integer converted into a string, + "a string. "
    #	- If Casino runs, it sets rand, assigns variable win_or_loss to string loss or won 

	# 